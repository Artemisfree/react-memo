export const SPADES_SUIT = "SPADES";
export const CROSS_SUIT = "CROSS";
export const DIAMONDS_SUIT = "DIAMONDS";
export const HEARTS_SUIT = "HEARTS";
